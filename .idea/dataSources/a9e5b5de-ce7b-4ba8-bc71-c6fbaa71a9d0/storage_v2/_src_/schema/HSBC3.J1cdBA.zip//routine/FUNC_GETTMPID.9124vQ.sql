CREATE FUNCTION FUNC_GETTMPID RETURN varchar2
IS
  TMPID   VARCHAR2(16);
  BEGIN
    SELECT TO_CHAR(SYSDATE,'yyyymmdd')
           || LPAD(
               RANDOM_SEQUENCE.NEXTVAL,
               8,
               '0'
           )
    INTO
      TMPID
    FROM DUAL;

    RETURN TMPID;
  END FUNC_GETTMPID;

/

